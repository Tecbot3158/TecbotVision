package com.chameleonvision.vision.enums;

public enum SortMode {
    Largest,Smallest,Highest,Lowest,Rightmost,Leftmost,Centermost
}
