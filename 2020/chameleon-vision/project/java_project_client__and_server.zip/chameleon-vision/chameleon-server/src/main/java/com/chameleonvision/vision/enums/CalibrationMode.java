package com.chameleonvision.vision.enums;

public enum CalibrationMode {
    None,Single,Dual
}
