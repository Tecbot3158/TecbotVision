package com.chameleonvision.network;

public enum NetworkIPMode {
	DHCP,
	STATIC,
	UNKNOWN
}
