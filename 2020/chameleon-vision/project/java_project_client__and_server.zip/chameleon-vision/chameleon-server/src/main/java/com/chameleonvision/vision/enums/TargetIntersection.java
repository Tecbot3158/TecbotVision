package com.chameleonvision.vision.enums;

public enum TargetIntersection {
    None,Up,Down,Left,Right
}
