package com.chameleonvision.vision.enums;

public enum TargetGroup {
    Single,
    Dual
}
