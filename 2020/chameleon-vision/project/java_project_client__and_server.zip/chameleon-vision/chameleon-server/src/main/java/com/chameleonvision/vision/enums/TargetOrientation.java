package com.chameleonvision.vision.enums;

public enum TargetOrientation {
    Portrait, Landscape
}
