package com.chameleonvision.vision.enums;

public enum TargetRegion {
    Center, Top, Bottom, Left, Right
}
