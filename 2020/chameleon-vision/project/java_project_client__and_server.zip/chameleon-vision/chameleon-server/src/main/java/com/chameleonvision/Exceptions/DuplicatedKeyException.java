package com.chameleonvision.Exceptions;

public class DuplicatedKeyException extends Exception{
    public DuplicatedKeyException(String message){
        super(message);
    }
}
