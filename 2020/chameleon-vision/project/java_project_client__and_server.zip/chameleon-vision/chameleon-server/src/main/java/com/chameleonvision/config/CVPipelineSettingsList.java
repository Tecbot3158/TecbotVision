package com.chameleonvision.config;

import com.chameleonvision.vision.pipeline.CVPipelineSettings;

import java.util.List;

public interface CVPipelineSettingsList extends List<CVPipelineSettings> {
}
